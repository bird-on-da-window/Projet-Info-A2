﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SolutionGraphique
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string standardAdresse = @"C:\Users\Utilisateur\Desktop\Travail\ESILV\Année 2\Semestre 4\PS Info\SolutionGraphique\SolutionGraphique\bin\Debug\net6.0\";
        string adresse = @"C:\Users\Utilisateur\Desktop\Travail\ESILV\Année 2\Semestre 4\PS Info\SolutionGraphique\SolutionGraphique\bin\Debug\net6.0\lac.bmp";
        string nomImage = "...";
        int degreRotation;
        int facteurAgrandissement;
        double facteurLuminosite;
        //MyImage image;
        byte rouge;
        byte bleu;
        byte vert;
        int zoom=1800;
        int compteurFractales = 0;
        int compteurLuminosite = 0;

        string nomImage2 = "...";
        string adresse2 = @"C:\Users\Utilisateur\Desktop\Travail\ESILV\Année 2\Semestre 4\PS Info\SolutionGraphique\SolutionGraphique\bin\Debug\net6.0\lac.bmp";

        public MainWindow()
        {
            InitializeComponent();
        }


        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)   // Gère le menu déroulant de la sélection des images.
        {
            ListBoxItem lbi = ((sender as ListBox).SelectedItem as ListBoxItem);

            nomImage = lbi.Content.ToString();
            adresse = standardAdresse + nomImage + ".bmp";
            Uri urlImage = new Uri(adresse, UriKind.Absolute);
            BitmapImage sourceImage = new BitmapImage(urlImage);

            MonImage.Source = sourceImage;


            tbStegano.Text = "On cache " + nomImage + " dans " + nomImage2;
            //image = new MyImage(adresse);
        }


        // Rotation

        private void RotationImage(object sender, RoutedEventArgs e)
        {
            MyImage rotation = MyImage.Rotation(adresse, degreRotation);
            rotation.From_Image_To_File(standardAdresse + nomImage + "Rotation" + degreRotation + ".bmp");
        }


        private void tbDegreRotation_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                try
                {
                    degreRotation = Convert.ToInt32(((TextBox)sender).Text);
                    RotationImage(sender, e);
                    FenetreAvertissementUser.Text = "Rotation effectuée avec succès. Image enregistrée.";
                }
                catch
                {
                    FenetreAvertissementUser.Text = "Veuillez entrer un nombre de degrés entier.";
                }
            }
        }

        // Agrandissement

        private void AgrandissementImage(object sender, RoutedEventArgs e)
        {
            MyImage agrandissement = MyImage.Agrandissement(adresse, facteurAgrandissement);
            agrandissement.From_Image_To_File(standardAdresse + nomImage + "Agrandissement" + facteurAgrandissement + ".bmp");
        }

        private void tbFacteurAgrandissement_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                try
                {
                    facteurAgrandissement = Convert.ToInt32(((TextBox)sender).Text);
                    AgrandissementImage(sender, e);
                    FenetreAvertissementUser.Text = "Agrandissement effectué avec succès. Image sauvegardée.";
                }
                catch
                {
                    FenetreAvertissementUser.Text = "Veuillez entrer un facteur d'agrandissement entier.";
                }
            }
        }

        // Filtres de convolution.

        private void lbConvo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxItem lbi = ((sender as ListBox).SelectedItem as ListBoxItem);
            string nomMission = lbi.Content.ToString();
            MyImage convo = MyImage.Convolution(adresse, nomMission);
            convo.From_Image_To_File(standardAdresse + nomImage + nomMission + ".bmp");
        }


        // Création d'une fractale


        private void Rouge_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Slider slider = sender as Slider;
            if(slider!= null)
            {
                rouge = (byte)slider.Value;
            }
        }

        private void Vert_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Slider slider = sender as Slider;
            if (slider != null)
            {
                vert = (byte)slider.Value;
            }
        }

        private void Bleu_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Slider slider = sender as Slider;
            if (slider != null)
            {
                bleu = (byte)slider.Value;
            }
        }

        private void Zoom_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Slider slider = sender as Slider;
            if (slider != null)
            {
                int a = (int)slider.Value;
                zoom = a;
            }
        }

        private void Setup1_Checked(object sender, RoutedEventArgs e)
        {
            bleu = 200;
            rouge = 255;
            vert = 200;
        }

        private void Setup2_Checked(object sender, RoutedEventArgs e)
        {
            rouge = 0;
            vert = 255;
            bleu = 0;
        }

        private void Setup3_Checked(object sender, RoutedEventArgs e)
        {
            rouge = 0;
            vert = 0;
            bleu = 255;
        }

        private void CreaFractale_Click(object sender, RoutedEventArgs e)
        {
            MyImage blanc = new MyImage(4000, 4000);
            blanc.FractaleMandelbrot2(zoom, rouge, vert, bleu);
            compteurFractales++;
            blanc.From_Image_To_File(standardAdresse + "fractale" + compteurFractales + ".bmp");
        }

        private void Luminosite_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Slider slider = sender as Slider;
            double K = slider.Value;
            if(K<1)
            {
                K = 1 - K;
            }
            if(slider != null)
            {
                facteurLuminosite = K;
            }
        }

        private void Luminosite_Valide(object sender, RoutedEventArgs e)
        {
            MyImage lumierechangee = MyImage.ChangementLuminosité(adresse, facteurLuminosite);
            compteurLuminosite++;
            lumierechangee.From_Image_To_File(standardAdresse + nomImage + "LumiChangee" + compteurLuminosite + ".bmp");
        }

        private void Inverser_Couleurs(object sender, RoutedEventArgs e)
        {
            MyImage couleursInversees = MyImage.InverserCouleurs(adresse);
            couleursInversees.From_Image_To_File(standardAdresse + nomImage + "CouleursInversees.bmp");
        }

        private void ListBoxItem_Selected(object sender, RoutedEventArgs e)
        {
            ListBoxItem lbi = ((sender as ListBox).SelectedItem as ListBoxItem);

            nomImage2 = lbi.Content.ToString();
            adresse2 = standardAdresse + nomImage2 + ".bmp";

            tbStegano.Text = "On cache " + nomImage + " dans " + nomImage2;
        }

        private void Stegano(object sender, RoutedEventArgs e)
        {
            string adresse1 = standardAdresse + nomImage + ".bmp";
            MyImage image1 = new MyImage(adresse1);
            string adresse2 = standardAdresse + nomImage2 + ".bmp";
            string adresseArrivee = standardAdresse + "Stegano_" + nomImage + "_dans_" + nomImage2 + ".bmp";
            string resultat = image1.Steganographie2(adresse2, adresseArrivee);
            FenetreAvertissementUser.Text= resultat;
        }

        private void Separer_Stegano_Click(object sender, RoutedEventArgs e)
        {
            string adresse = standardAdresse + "Stegano_coco_dans_lac" + ".bmp";
            MyImage stegano = MyImage.ReveleSteganographie2(adresse, standardAdresse+"imageCachee.bmp");
            stegano.From_Image_To_File(standardAdresse + "imageBase.bmp");
        }

        private void FractaleBuddha_Click(object sender, RoutedEventArgs e)
        {
            MyImage blanc = new MyImage(4000, 4000);
            blanc.FractaleBuddha();
            compteurFractales++;
            blanc.From_Image_To_File(standardAdresse + "fractaleBuddha" + compteurFractales + ".bmp");
        }







        //Pixel option1 = new Pixel(200, 255, 200);
        //byte rouge = option1.Rouge;
        //byte vert = option1.Vert;
        //byte bleu = option1.Bleu;


        //MyImage blanc = new MyImage(4000, 4000);
        //blanc.FractaleMandelbrot2(1600, rouge, vert, bleu);
        //blanc.From_Image_To_File("blanc4.bmp");
    }
}
