﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolutionGraphique
{
    internal class PixelAlt
    {
        byte y;
        byte cb;
        byte cr;

        public PixelAlt(byte y, byte cb, byte cr)
        {
            this.y = y;
            this.cb = cb;
            this.cr = cr;
        }


        public byte Y
        {
            get { return y; }
            set { y = value; }
        }

        public byte Cb
        {
            get { return cb; }
            set { cb = value; }
        }

        public byte Cr
        {
            get { return cr; }
            set { cr = value; }
        }
    }
}
