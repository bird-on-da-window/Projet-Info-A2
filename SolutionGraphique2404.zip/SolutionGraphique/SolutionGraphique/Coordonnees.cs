﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolutionGraphique
{
    class Coordonnees
    {
        public int x;
        public int y;

        public Coordonnees(int X, int Y)
        {
            this.x = X;
            this.y = Y;
        }
    }
}
