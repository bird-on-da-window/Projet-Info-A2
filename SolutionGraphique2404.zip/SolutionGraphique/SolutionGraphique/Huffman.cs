﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolutionGraphique
{
    class Huffman
    {
        //Noeud Root;
        Dictionary<Pixel, int> frequencePixels = new Dictionary<Pixel, int>();

        public Huffman(Pixel[,] image)
        {
            List<Pixel> list = new List<Pixel>();
            for (int i = 0; i < image.GetLength(0); i++)
            {
                for (int j = 0; j < image.GetLength(1); j++)
                {
                    list.Add(image[i, j]);
                }
            }
            var result = list.GroupBy(x => x).ToDictionary(x => x.Key, x => x.Count());
            this.frequencePixels = result;
        }

        public Dictionary<Pixel, int> FrequencePixels
        {
            get { return frequencePixels; }
        }

        public static void ParcoursEnDiagonale(int[,] mat1)
        {
            int[,] mat = new int[,] { { 0, 1, 2 }, { 3, 4, 5 }, { 6, 7, 8 } };
            int i = -1;
            int j = 0;
            int m = 1;
            int k = 0;


            while (k < (mat.GetLength(0) * mat.GetLength(0)))
            {
                i += m;
                j -= m;

                if (j >= mat.GetLength(1))
                {
                    j--;
                    i += 2;
                    m = -m;
                }
                if (i >= mat.GetLength(0))
                {
                    i--;
                    j += 2;
                    m = -m;
                }
                if (j < 0)
                {
                    j++;
                    m = -m;
                }
                if (i < 0)
                {
                    i++;
                    m = -m;
                }
                Console.Write(mat[i, j] + " ");
                k++;
            }
        }
    }
}
