﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolutionGraphique
{
    class Noeud
    {
        public Pixel pixel;
        public double frequence;
        public Noeud noeudSuivantG;
        public Noeud noeudSuivantD;

        public Noeud(Pixel pixel, double frequence, Noeud NoeudSuivantG, Noeud NoeudSuivantD)
        {
            this.pixel = pixel;
            this.frequence = frequence;
            this.noeudSuivantD = NoeudSuivantD;
            this.noeudSuivantG = NoeudSuivantG;
        }
    }
}
