﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;
using System.Media;
using System.ComponentModel;

namespace SolutionGraphique
{
    class MyImage
    {
        public string type;
        public int tailleFichier;
        public int tailleOffset;
        public int largeur;
        public int hauteur;
        public int nbBitsParCouleur;

        public int tailleImage;
        public int resolutionH;
        public int resolutionV;
        public Pixel[,] matImage;



        public MyImage(string myfile)       // lit un fichier .bmp et le transforme en instance de la classe MyImage
        {
            string adresse = myfile;
            byte[] file = File.ReadAllBytes(adresse);
            this.type = TypeImage(file);
            this.tailleFichier = TailleFichier(file);
            this.tailleOffset = TailleOffset(file);
            Dimensions(file);
            this.nbBitsParCouleur = BitCouleur(file);
            this.matImage = new Pixel[hauteur, largeur];
            RemplissageMatrice(file);
            this.tailleImage = TailleImage(file);
            this.resolutionH = ResolutionH(file);
            this.resolutionV = ResolutionV(file);
        }

        public MyImage(int hauteur, int largeur)
        {
            this.type = "BitMap";
            this.tailleFichier = 0;
            this.tailleOffset = 54;
            this.largeur = largeur;
            this.hauteur = hauteur;
            this.nbBitsParCouleur = 24;
            this.matImage = new Pixel[hauteur, largeur];
            for (int i = 0; i < matImage.GetLength(0); i++)
            {
                for (int j = 0; j < matImage.GetLength(1); j++)
                {
                    this.matImage[i, j] = new Pixel(255, 255, 255);
                }
            }
            this.tailleImage = 0;
            this.resolutionH = 0;
            this.resolutionV = 0;

        }     // Surcharge du constructeur pour créer un image entièrement blanche juste à partir de ses dimensions. Cela permet d'avoir une base pour la création d'image comme les fractales.

        public void From_Image_To_File(string file)      // Prend une instance de MyImage et la transforme en fichier binaire respectant la structure du fichier.bmp (opération inverse du constructeur)
        {
            byte[] fichier = new byte[54 + matImage.GetLength(0) * matImage.GetLength(1) * 3];

            // Header

            fichier[0] = 66;
            fichier[1] = 77;
            byte[] tailleF = Convertir_Int_To_Endian(tailleFichier, 4);
            for (int i = 0; i < tailleF.Length; i++)
            {
                fichier[2 + i] = tailleF[i];
            }
            for (int i = 0; i < 4; i++)
            {
                fichier[6 + i] = 0;
            }
            byte[] offset = Convertir_Int_To_Endian(tailleOffset, 4);
            for (int i = 0; i < offset.Length; i++)
            {
                fichier[10 + i] = offset[i];
            }


            // Header info

            fichier[14] = 40;
            for (int i = 15; i < 17; i++)
            {
                fichier[i] = 0;
            }
            byte[] endLargeur = Convertir_Int_To_Endian(largeur, 4);
            for (int i = 0; i < endLargeur.Length; i++)
            {
                fichier[18 + i] = endLargeur[i];
            }
            byte[] endHauteur = Convertir_Int_To_Endian(hauteur, 4);
            for (int i = 0; i < endHauteur.Length; i++)
            {
                fichier[22 + i] = endHauteur[i];
            }
            fichier[26] = 1;
            fichier[27] = 0;
            byte[] bitsParCouleur = Convertir_Int_To_Endian(nbBitsParCouleur, 2);
            for (int i = 0; i < bitsParCouleur.Length; i++)
            {
                fichier[28 + i] = bitsParCouleur[i];
            }
            for (int i = 0; i < 4; i++)
            {
                fichier[30 + i] = 0;
            }
            byte[] tailledeImage = Convertir_Int_To_Endian(tailleImage, 4);
            for (int i = 0; i < tailledeImage.Length; i++)
            {
                fichier[34 + i] = tailledeImage[i];
            }
            byte[] resoH = Convertir_Int_To_Endian(resolutionH, 4);
            for (int i = 0; i < resoH.Length; i++)
            {
                fichier[38 + i] = resoH[i];
            }
            byte[] resoV = Convertir_Int_To_Endian(resolutionV, 4);
            for (int i = 0; i < resoV.Length; i++)
            {
                fichier[42 + i] = resoV[i];
            }
            for (int i = 46; i < 54; i++)
            {
                fichier[i] = 0;
            }


            // Matrice de Pixels

            int compteur = 53;
            for (int i = 0; i < hauteur; i++)
            {
                for (int j = 0; j < largeur; j++)
                {
                    fichier[compteur] = matImage[i, j].Rouge;
                    compteur++;
                    fichier[compteur] = matImage[i, j].Vert;
                    compteur++;
                    fichier[compteur] = matImage[i, j].Bleu;
                    compteur++;
                }
            }
            File.WriteAllBytes(file, fichier);
        }


        public string TypeImage(byte[] tab)
        {
            string type;
            if (tab[0] == 66 && tab[1] == 77)
            {
                type = "BitMap";
            }
            else type = null;
            return type;
        }     // Définit le type de l'image grâce au deux premier octets du tableau. Le programme ici présent ne traite que les images.bmp, commençant par 66 77.


        public int TailleFichier(byte[] tab)     // Relève la taille du fichier et l'inscrit dans l'instance de MyImage.
        {
            byte[] octets = new byte[4];
            for (int i = 0; i < octets.Length; i++)
            {
                octets[i] = tab[i + 2];
            }
            int taille = Convertir_Endian_To_Int(octets, 0, 4);
            return taille;
        }         // 


        public int TailleOffset(byte[] tab)
        {
            byte[] octets = new byte[4];
            for (int i = 0; i < octets.Length; i++)
            {
                octets[i] = tab[i + 10];
            }
            return Convertir_Endian_To_Int(octets, 0, 4);
        }   // Relève la taille offset du fichier et l'inscrit dans l'instance de MyImage.


        public void Dimensions(byte[] tab)       // Relève la hauteur et la largeur de l'image et les inscrit dans l'instance de MyImage.
        {
            byte[] octetsL = new byte[4];
            byte[] octetsH = new byte[4];
            for (int i = 0; i < octetsL.Length; i++)
            {
                octetsL[i] = tab[i + 18];
                octetsH[i] = tab[i + 22];
            }
            this.largeur = Convertir_Endian_To_Int(octetsL, 0, 4);
            this.hauteur = Convertir_Endian_To_Int(octetsH, 0, 4);
        }


        public int BitCouleur(byte[] tab)                     // Relève le nombre de bits par couleur et l'inscrit dans l'instance de MyImage.
        {
            byte[] octetsCouleur = new byte[2];
            for (int i = 0; i < octetsCouleur.Length; i++)
            {
                octetsCouleur[i] = tab[i + 28];
            }
            return Convertir_Endian_To_Int(octetsCouleur, 0, 2);
        }


        public int TailleImage(byte[] tab)
        {
            byte[] tailleImage = new byte[4];
            for (int i = 0; i < tailleImage.Length; i++)
            {
                tailleImage[i] = tab[i + 34];
            }
            return Convertir_Endian_To_Int(tailleImage, 0, 4);
        }                   // Relève la taille de l'image et l'inscrit dans l'instance de MyImage.


        public int ResolutionH(byte[] tab)
        {
            byte[] resolutionH = new byte[4];
            for (int i = 0; i < resolutionH.Length; i++)
            {
                resolutionH[i] = tab[i + 38];
            }
            return Convertir_Endian_To_Int(resolutionH, 0, 4);
        }                  // Relève la résolution horizontale de l'image et l'inscrit dans l'instance de MyImage.


        public int ResolutionV(byte[] tab)
        {
            byte[] resolutionV = new byte[4];
            for (int i = 0; i < resolutionV.Length; i++)
            {
                resolutionV[i] = tab[i + 42];
            }
            return Convertir_Endian_To_Int(resolutionV, 0, 4);
        }                 // Relève la résolution verticale de l'image et l'inscrit dans l'instance de MyImage.


        public void RemplissageMatrice(byte[] file)              // Les octets ne faisant pas partie du header ni du header info sont la matrice de Pixels.
        {
            
            int a = 53;
            for (int i = 0; i < hauteur; i++)
            {
                for (int j = 0; j < largeur; j++)
                {
                    this.matImage[i, j] = new Pixel(file[a], file[a + 1], file[a + 2]);
                    a += 3;
                }
            }
        }          


        public int Convertir_Endian_To_Int(byte[] tab, int debut, int nbOctet)     // Convertit une séquence d’octets au format little endian en entier
        {
            int conversion = 0;
            for (int i = debut; i < debut + nbOctet; i++)
            {
                conversion += (int)(tab[i] * Math.Pow(256, i - debut));
            }
            return conversion;
        }


        public byte[] Convertir_Int_To_Endian(int val, int nbOctet)        // Convertit un entier en séquence d’octets au format little endian
        {
            byte[] tab = new byte[nbOctet];
            for (int i = nbOctet - 1; i >= 0; i--)
            {
                tab[i] = (byte)(val / Math.Pow(256, i));
                val = (int)(val % Math.Pow(256, i));
            }
            return tab;
        }


        public static MyImage ChangementLuminosité(string file, double facteur)
        {
            MyImage image = new MyImage(file);

            Pixel[,] mat = new Pixel[image.hauteur,image.largeur];
            for (int i = 0; i < image.matImage.GetLength(0); i++)
            {
                for (int j = 0; j < image.matImage.GetLength(1); j++)
                {
                    double intensiteCouleurR = (double)image.matImage[i,j].Rouge;
                    intensiteCouleurR = intensiteCouleurR / facteur;
                    if(intensiteCouleurR>255)
                    {
                        intensiteCouleurR = 255;
                    }
                    byte R = (byte)intensiteCouleurR;
                    double intensiteCouleurB = (double)image.matImage[i, j].Bleu;
                    intensiteCouleurB = intensiteCouleurB / facteur;
                    if (intensiteCouleurB > 255)
                    {
                        intensiteCouleurB = 255;
                    }
                    byte B = (byte) intensiteCouleurB;
                    double intensiteCouleurV = (double)image.matImage[i, j].Vert;
                    intensiteCouleurV = intensiteCouleurV / facteur;
                    if (intensiteCouleurV > 255)
                    {
                        intensiteCouleurV = 255;
                    }
                    byte V = (byte)intensiteCouleurV;
                    mat[i, j] = new Pixel(R, V, B);
                }
            }
            image.matImage = mat;
            return image;
        }


        public static MyImage InverserCouleurs(string file)
        {
            MyImage image = new MyImage(file);

            Pixel[,] mat = new Pixel[image.hauteur, image.largeur];
            for(int i = 0; i < image.hauteur; i++)
            {
                for(int j = 0; j < image.largeur; j++)
                {
                    mat[i, j] = new Pixel((byte)(255 - (int)image.matImage[i, j].Rouge), (byte)(255 - (int)image.matImage[i, j].Vert), (byte)(255 - (int)image.matImage[i, j].Bleu));
                }
            }
            image.matImage = mat;
            return image;
        }


        


        public static MyImage Agrandissement(string file, int facteur)
        {
            MyImage image = new MyImage(file);

            int hauteur = image.hauteur;
            int largeur = image.largeur;

            Pixel[,] matAgrandie = new Pixel[facteur * hauteur, facteur * largeur];
            for (int i = 0; i < image.hauteur; i++)
            {
                for (int j = 0; j < image.largeur; j++)
                {
                    for (int k = 0; k < facteur; k++)
                    {
                        for (int l = 0; l < facteur; l++)
                        {
                            matAgrandie[i * facteur + k, j * facteur + l] = new Pixel(image.matImage[i, j].Rouge, image.matImage[i, j].Vert, image.matImage[i, j].Bleu);
                        }
                    }
                }
            }
            image.tailleImage = image.tailleImage * facteur * facteur;
            image.hauteur = hauteur * facteur;
            image.largeur = largeur * facteur;
            image.matImage = matAgrandie;
            return image;
        }


        public static MyImage Rotation(string file, int degre)
        {

            MyImage image = new MyImage(file);

            double radian = degre;
            radian = (radian / 180) * Math.PI;


            int origineImageDepartX = image.largeur / 2;
            int origineImageDepartY = image.hauteur / 2;

            double R = Math.Sqrt((double)origineImageDepartX * (double)origineImageDepartX + (double)origineImageDepartY * (double)origineImageDepartY);
            double theta1 = Math.Asin((double)origineImageDepartY / R);

            //PARTIE 1
            double thetaTotal = theta1 + radian;


            int hArrivee = (int)(Math.Sin(thetaTotal) * R);
            if (hArrivee % 2 != 0)
            {
                hArrivee++;
            }
            hArrivee = Math.Abs(hArrivee * 2);
            Console.WriteLine("hauteur arrivee = " + hArrivee);
            int lArrivee = (int)(Math.Cos(thetaTotal) * R);
            if (lArrivee % 2 != 0)
            {
                lArrivee++;
            }
            lArrivee = Math.Abs(lArrivee * 2);
            Console.WriteLine("longueur arrivee = " + lArrivee);


            //PARTIE 2
            thetaTotal = theta1 - radian;


            int hArrivee2 = (int)(Math.Sin(thetaTotal) * R);
            if (hArrivee2 % 2 != 0)
            {
                hArrivee2++;
            }
            hArrivee2 = Math.Abs(hArrivee2 * 2);
            Console.WriteLine("hauteur arrivee = " + hArrivee2);
            int lArrivee2 = (int)(Math.Cos(thetaTotal) * R);
            if (lArrivee2 % 2 != 0)
            {
                lArrivee2++;
            }
            lArrivee2 = Math.Abs(lArrivee2 * 2);
            Console.WriteLine("longueur arrivee = " + lArrivee2);




            if (Math.Abs(lArrivee2) > Math.Abs(lArrivee))
            {
                lArrivee = lArrivee2;
            }
            if (Math.Abs(hArrivee2) > Math.Abs(hArrivee))
            {
                hArrivee = hArrivee2;
            }

            //int hArrivee = image.hauteur * 2;
            //int lArrivee = image.largeur * 2;
            int origineImageArriveeX = lArrivee / 2;
            int origineImageArriveeY = hArrivee / 2;


            Pixel[,] mat = new Pixel[hArrivee, lArrivee];

            for (int i = -1 * (hArrivee / 2); i < (hArrivee / 2); i++)
            {
                for (int j = -1 * (lArrivee / 2); j < (lArrivee / 2); j++)
                {
                    double r = Math.Sqrt(j * j + i * i);
                    double sommeAngles = Math.Acos(j / r);
                    if (i <= 0) sommeAngles = -1 * sommeAngles;
                    double t = sommeAngles - radian;
                    double X = r * Math.Cos(t);
                    double Y = r * Math.Sin(t);
                    int x = (int)Math.Round(X);
                    int y = (int)Math.Round(Y);
                    if (((origineImageDepartX + x) > 0) && ((origineImageDepartX + x) < image.largeur) && ((origineImageDepartY + y) > 0) && ((origineImageDepartY + y) < image.hauteur))
                    {
                        mat[origineImageArriveeY + i, origineImageArriveeX + j] = image.matImage[origineImageDepartY + y, origineImageDepartX + x];
                        //mat[origineImageArriveeY + i, origineImageArriveeX + j] = new Pixel(0, 250, 0);
                    }
                    else
                    {
                        mat[origineImageArriveeY + i, origineImageArriveeX + j] = new Pixel(0, 0, 0);
                    }
                }
            }
            image.hauteur = hArrivee;
            image.largeur = lArrivee;
            image.MatImage = mat;
            return image;
        }



        public static MyImage Convolution(string file, string mission)
        {
            double min = 255;
            double max = 0;
            MyImage image = new MyImage(file);
            Pixel[,] mat = new Pixel[image.hauteur, image.largeur];

            int diviseur = 0;
            int[,] convolution = new int[0, 0];
            if (mission == "id")
            {
                convolution = new int[5, 5] { { 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0 }, { 0, 0, 1, 0, 0 }, { 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0 } };
                diviseur = 1;
            }
            else if (mission == "Augmenter le contraste")
            {
                convolution = new int[5, 5] { { 0, 0, 0, 0, 0 }, { 0, 0, -1, 0, 0 }, { 0, -1, 5, -1, 0 }, { 0, 0, -1, 0, 0 }, { 0, 0, 0, 0, 0 } };
                diviseur = 1;
            }
            else if (mission == "Flou")
            {
                convolution = new int[5, 5] { { 0, 0, 0, 0, 0 }, { 0, 1, 1, 1, 0 }, { 0, 1, 1, 1, 0 }, { 0, 1, 1, 1, 0 }, { 0, 0, 0, 0, 0 } };
                diviseur = 9;
            }
            else if (mission == "Renforcement des bords")
            {
                convolution = new int[3, 3] { { 0, 0, 0 }, { -1, 1, 0 }, { 0, 0, 0 } };
                diviseur = 1;
            }
            else if (mission == "Détection des bords")
            {
                convolution = new int[3, 3] { { 0, 1, 0 }, { 1, -4, 1 }, { 0, 1, 0 } };
                diviseur = 1;
            }
            else if (mission == "Repoussage")
            {
                convolution = new int[3, 3] { { -2, -1, 0 }, { -1, 1, 1 }, { 0, 1, 2 } };
                diviseur = 1;
            }


            for (int x = 0; x < image.largeur; x++)
            {
                for (int y = 0; y < image.hauteur; y++)
                {
                    double sommeR = 0;
                    double sommeB = 0;
                    double sommeV = 0;

                    for (int filtreY = 0; filtreY < convolution.GetLength(0); filtreY++)
                    {
                        for (int filtreX = 0; filtreX < convolution.GetLength(1); filtreX++)
                        {
                            if ((x < 2) || (y < 2) || (y >= image.hauteur - 2) || (x >= image.largeur - 2))
                            {
                                mat[y, x] = new Pixel(255, 255, 255);
                            }
                            else
                            {
                                int imageX = (x - 2 + filtreX + image.largeur) % image.largeur;
                                int imageY = (y - 2 + filtreY + image.hauteur) % image.hauteur;

                                sommeR += image.matImage[imageY, imageX].Rouge * convolution[filtreY, filtreX];
                                sommeB += image.matImage[imageY, imageX].Bleu * convolution[filtreY, filtreX];
                                sommeV += image.matImage[imageY, imageX].Vert * convolution[filtreY, filtreX];

                                /*for (int k = -2; k < 3; k++)
                                {
                                    for (int l = -2; l < 3; l++)
                                    {
                                        sommeR += convolution[l + 2, k + 2] * (int)image.matImage[i + l, j + k].Rouge;
                                        sommeB += convolution[l + 2, k + 2] * (int)image.matImage[i + l, j + k].Bleu;
                                        sommeV += convolution[l + 2, k + 2] * (int)image.matImage[i + l, j + k].Vert;
                                    }
                                }
                                int a = 0;

                                for (int k = -2; k < 3; k++)
                                {
                                    for (int l = -2; l < 3; l++)
                                    {
                                        sommeR += convolution[k + 2, l + 2] * (int)image.matImage[i + k, j + l].Rouge;
                                        sommeB += convolution[k + 2, l + 2] * (int)image.matImage[i + k, j + l].Bleu;
                                        sommeV += convolution[k + 2, l + 2] * (int)image.matImage[i + k, j + l].Vert;
                                        a++;
                                    }
                                }

                                sommeR = sommeR / diviseur;
                                sommeB = sommeB / diviseur;
                                sommeV = sommeV / diviseur;*/

                                /*if (sommeR < 0) sommeR += 255;
                                if(sommeB < 0) sommeB += 255;
                                if (sommeV < 0) sommeV += 255;*/

                                /*if (mission == "flou")
                                {
                                    sommeR += 60;
                                    sommeB += 60;
                                    sommeV += 60;
                                }


                                if (sommeR < min) min = sommeR;
                                if (sommeR > max) max = sommeR;



                                byte newR = (byte)sommeR;
                                byte newB = (byte)sommeB;
                                byte newV = (byte)sommeV;

                                mat[i, j] = new Pixel(newR, newV, newB);*/

                            }
                        }
                    }


                    sommeR = sommeR / diviseur;
                    sommeB = sommeB / diviseur;
                    sommeV = sommeV / diviseur;


                    if (sommeR < min) min = sommeR;
                    if (sommeR > max) max = sommeR;

                    while (sommeR < 0) sommeR++;
                    while (sommeB < 0) sommeB++;
                    while (sommeV < 0) sommeV++;

                    while (sommeR > 255) sommeR--;
                    while (sommeB > 255) sommeB--;
                    while (sommeV > 255) sommeV--;

                    /*sommeR = sommeR % 255;
                    sommeB = sommeB % 255;
                    sommeV = sommeV % 255;*/

                    byte rouge = (byte)sommeR;
                    byte vert = (byte)sommeV;
                    byte bleu = (byte)sommeB;

                    mat[y, x] = new Pixel(rouge, vert, bleu);
                }
            }

            /*if (convolution.GetLength(0) == 5)
            {
                for (int i = 0; i < image.hauteur; i++)
                {
                    for (int j = 0; j < image.largeur; j++)
                    {
                        if ((i < 2) || (j < 2) || (i >= image.hauteur - 2) || (j >= image.largeur - 2))
                        {
                            mat[i, j] = new Pixel(255, 255, 255);
                        }
                        else
                        {
                            int sommeR = 0;
                            int sommeB = 0;
                            int sommeV = 0;
                            /*for (int k = -2; k < 3; k++)
                            {
                                for (int l = -2; l < 3; l++)
                                {
                                    sommeR += convolution[l + 2, k + 2] * (int)image.matImage[i + l, j + k].Rouge;
                                    sommeB += convolution[l + 2, k + 2] * (int)image.matImage[i + l, j + k].Bleu;
                                    sommeV += convolution[l + 2, k + 2] * (int)image.matImage[i + l, j + k].Vert;
                                }
                            }
                            int a = 0;

                            for (int k = -2; k < 3; k++)
                            {
                                for (int l = -2; l < 3; l++)
                                {
                                    sommeR += convolution[k + 2, l + 2] * (int)image.matImage[i + k, j + l].Rouge;
                                    sommeB += convolution[k + 2, l + 2] * (int)image.matImage[i + k, j + l].Bleu;
                                    sommeV += convolution[k + 2, l + 2] * (int)image.matImage[i + k, j + l].Vert;
                                    a++;
                                }
                            }

                            sommeR = sommeR / diviseur;
                            sommeB = sommeB / diviseur;
                            sommeV = sommeV / diviseur;

                            /*if (sommeR < 0) sommeR += 255;
                            if(sommeB < 0) sommeB += 255;
                            if (sommeV < 0) sommeV += 255;*/

            /*if (mission == "flou")
            {
                sommeR += 60;
                sommeB += 60;
                sommeV += 60;
            }


            if (sommeR < min) min = sommeR;
            if (sommeR > max) max = sommeR;



            byte newR = (byte)sommeR;
            byte newB = (byte)sommeB;
            byte newV = (byte)sommeV;

            mat[i, j] = new Pixel(newR, newV, newB);

        }
    }
} 



        }
            else
            {
                for (int i = 0; i < image.hauteur; i++)
                {
                    for (int j = 0; j < image.largeur; j++)
                    {
                        if ((i < 1) || (j < 1) || (i >= image.hauteur - 1) || (j >= image.largeur - 1))
                        {
                            mat[i, j] = new Pixel(0, 0, 0);
                        }
                        else
                        {
                            int sommeR = 0;
                            int sommeB = 0;
                            int sommeV = 0;
                            for (int k = -1; k < 2; k++)
                            {
                                for (int l = -1; l < 2; l++)
                                {
                                    sommeR += convolution[k + 1, l + 1] * image.matImage[i + k, j + l].Rouge;
                                    sommeB += convolution[k + 1, l + 1] * image.matImage[i + k, j + l].Bleu;
                                    sommeV += convolution[k + 1, l + 1] * image.matImage[i + k, j + l].Vert;
                                }
                            }
                            sommeR = sommeR / diviseur;
                            sommeB = sommeB / diviseur;
                            sommeV = sommeV / diviseur;


                            /*if (mission == "flou")
                            {
                                sommeR += 60;
                                sommeB += 60;
                                sommeV += 60;
                            }


                            if (sommeR < min) min = sommeR;
                            if (sommeR > max) max = sommeR;

                            byte newR = (byte)sommeR;
                            byte newB = (byte)sommeB;
                            byte newV = (byte)sommeV;

                            mat[i, j] = new Pixel(newR, newV, newB);
                        }
                    }
                }
            }*/


            Console.WriteLine("Min = " + min + ", max = " + max);
            image.MatImage = mat;
            return image;
        }


        public void FractaleMandelbrot2(int zoom, byte rouge = 255, byte vert = 255, byte bleu = 255)
        {
            /*if(zoom==0 || zoom==null)
            {
                zoom = 1800;
            }*/
            bool couleurdefault = false;
            double x1 = -2.1;
            double x2 = 0.6;
            double y1 = -1.2;
            double y2 = 1.2;
            int iteration_max = 50;
            int A = 0;




            int hauteur = Convert.ToInt32((y2 - y1) * (double)zoom);
            int largeur = Convert.ToInt32((x2 - x1) * (double)zoom);
            this.hauteur = hauteur;
            this.largeur = largeur;


            Pixel[,] mat = new Pixel[hauteur, largeur];

            for (int j = 0; j < largeur; j++)
            {
                //Console.WriteLine("ok"+A);
                //A++;
                for (int i = 0; i < hauteur; i++)
                {
                    double c_r = j / (double)zoom + x1;
                    double c_i = i / (double)zoom + y1;
                    double z_r = 0;
                    double z_i = 0;
                    int k = 0;

                    while ((z_r * z_r + z_i * z_i < 4) && (k < iteration_max))
                    {
                        double tmp = z_r;
                        z_r = z_r * z_r - z_i * z_i + c_r;
                        z_i = 2 * z_i * tmp + c_i;
                        k++;
                    }

                    int color = 0;
                    int color2 = 0;
                    int color3 = 0;
                    if (couleurdefault == true)
                    {
                        color = ((k + 3) * 500 / iteration_max) + 1;   // 500 : Luminosité du fond
                        color2 = (color / 3) + 1;
                    }
                    else
                    {
                        color = (int)((k + 3) * 500 * ((double)rouge / 255) / iteration_max) + 1;
                        color2 = (int)((k + 3) * 500 * ((double)bleu / 255) / iteration_max) + 1;
                        color3 = (int)((k + 3) * 500 * ((double)vert / 255) / iteration_max) + 1;
                    }

                    //Console.WriteLine(color);
                    //Console.WriteLine(color3);
                    while (color > 255)
                    {
                        color--;
                    }
                    while (color2 > 255)
                    {
                        color2--;
                    }
                    while (color3 > 255)
                    {
                        color3--;
                    }

                    byte colorpix = (byte)color;
                    byte colorpix2 = (byte)color2;
                    byte colorpix3 = (byte)color3;



                    if (k == iteration_max)
                    {
                        if (!(rouge >= 200 && bleu >= 200 && vert >= 200))
                        {
                            mat[i, j] = new Pixel(255, 255, 255);
                        }
                        else
                        {
                            mat[i, j] = new Pixel(0, 0, 0);
                        }
                    }
                    else
                    {
                        mat[i, j] = new Pixel(colorpix, colorpix2, colorpix3);
                    }
                }
            }
            this.matImage = mat;

        }


        public static string Steganographie(string adresse1, string adresse2, string adresseArrivee)
        {
            // adresse1 à cacher dans adresse2

            MyImage image1 = new MyImage(adresse1);

            MyImage image2 = new MyImage(adresse2);

            if(image1.hauteur>image2.hauteur || image1.largeur>image2.largeur)
            {
                return ("Impossible. L'image à cacher doit être plus petite que celle dans laquelle on cache.");
            }

            image2.resolutionH = image1.hauteur;
            image2.resolutionV = image2.largeur;


            Pixel[,] mat = new Pixel[image2.hauteur, image1.largeur];
            for(int i = 0; i < image1.matImage.GetLength(0); i++)
            {
                for(int j = 0; j < image1.matImage.GetLength(1); j++)
                {
                    int R = (byte)image1.matImage[i, j].Rouge;
                    int r = 0;
                    if(R>=128)
                    {
                        R -= 128;
                        r += 8;
                    }
                    if(R>=64)
                    {
                        R -= 64;
                        r += 4;
                    }
                    if(R>=32)
                    {
                        R -= 32;
                        r += 2;
                    }
                    if(R>=16)
                    {
                        R -= 16;
                        r = 1;
                    }
                    int aEnlever = R;
                    R = (byte)image1.matImage[i, j].Rouge;
                    R = R - aEnlever + r;

                    int V = (byte)image1.matImage[i, j].Vert;
                    int v = 0;
                    if (V >= 128)
                    {
                        V -= 128;
                        v += 8;
                    }
                    if (V >= 64)
                    {
                        V -= 64;
                        v += 4;
                    }
                    if (V >= 32)
                    {
                        V -= 32;
                        v += 2;
                    }
                    if (V >= 16)
                    {
                        V -= 16;
                        v = 1;
                    }
                    aEnlever = V;
                    V = (byte)image1.matImage[i, j].Vert;
                    V = V - aEnlever + v;

                    int B = (byte)image1.matImage[i, j].Bleu;
                    int b = 0;
                    if (B >= 128)
                    {
                        B -= 128;
                        b += 8;
                    }
                    if (B >= 64)
                    {
                        B -= 64;
                        b += 4;
                    }
                    if (B >= 32)
                    {
                        B -= 32;
                        b += 2;
                    }
                    if (B >= 16)
                    {
                        B -= 16;
                        b = 1;
                    }
                    aEnlever = B;
                    B = (byte)image1.matImage[i, j].Rouge;
                    B = B - aEnlever + b;

                    mat[i, j] = new Pixel((byte)R, (byte)V, (byte)B);
                }
            }
            image2.matImage = mat;
            image2.From_Image_To_File(adresseArrivee);
            return ("Succès de l'opération.");
        }

        public static string FromByteToBits(byte a)
        {
            string b = Convert.ToString(a, 2);
            {
                while (b.Length < 8)
                {
                    string c = "0" + b;
                    b = c;
                }
            }
            return b;
        }

        public static byte FromBitsToByte(string a)
        {
            byte b = 0;
            for (int i = 0; i < 8; i++)
            {
                b += (byte)(Convert.ToDouble(Convert.ToString(a[i])) * Math.Pow(2, (double)(7 - i)));
            }
            return b;
        }

        public string Steganographie2(string adresse2, string adresseArrivee)
        {
            // image à cacher dans celle de adresse2

            MyImage image2 = new MyImage(adresse2);

            if (hauteur > image2.hauteur || largeur > image2.largeur)
            {
                return ("Impossible. L'image à cacher doit être plus petite que celle dans laquelle on cache.");
            }

            image2.resolutionH = hauteur;
            image2.resolutionV = largeur;


            Pixel[,] mat = new Pixel[image2.hauteur, image2.largeur];
            for (int i = 0; i < image2.hauteur; i++)
            {
                for (int j = 0; j < image2.largeur; j++)
                {
                    if(i<hauteur && j<largeur)
                    {
                        string rougeDepart = FromByteToBits(image2.matImage[i, j].Rouge);
                        string rougeACacher = FromByteToBits(matImage[i, j].Rouge);
                        string nouveauRouge = Convert.ToString(rougeDepart[0]) + Convert.ToString(rougeDepart[1]) + Convert.ToString(rougeDepart[2]) + Convert.ToString(rougeDepart[3]);
                        nouveauRouge += Convert.ToString(rougeACacher[0]) + Convert.ToString(rougeACacher[1]) + Convert.ToString(rougeACacher[2]) + Convert.ToString(rougeACacher[3]);
                        byte R = FromBitsToByte(nouveauRouge);

                        string bleuDepart = FromByteToBits(image2.matImage[i, j].Bleu);
                        string bleuACacher = FromByteToBits(matImage[i, j].Bleu);
                        string nouveauBleu = Convert.ToString(bleuDepart[0]) + Convert.ToString(bleuDepart[1]) + Convert.ToString(bleuDepart[2]) + Convert.ToString(bleuDepart[3]);
                        nouveauBleu += Convert.ToString(bleuACacher[0]) + Convert.ToString(bleuACacher[1]) + Convert.ToString(bleuACacher[2]) + Convert.ToString(bleuACacher[3]);
                        byte B = FromBitsToByte(nouveauBleu);

                        string vertDepart = FromByteToBits(image2.matImage[i, j].Vert);
                        string vertACacher = FromByteToBits(matImage[i, j].Vert);
                        string nouveauVert = Convert.ToString(vertDepart[0]) + Convert.ToString(vertDepart[1]) + Convert.ToString(vertDepart[2]) + Convert.ToString(vertDepart[3]);
                        nouveauVert += Convert.ToString(vertACacher[0]) + Convert.ToString(vertACacher[1]) + Convert.ToString(vertACacher[2]) + Convert.ToString(vertACacher[3]);
                        byte V = FromBitsToByte(nouveauVert);

                        /*int R = (int)matImage[i, j].Rouge;
                        int r = 0;
                        if (R >= 128)
                        {
                            R -= 128;
                            r += 8;
                        }
                        if (R >= 64)
                        {
                            R -= 64;
                            r += 4;
                        }
                        if (R >= 32)
                        {
                            R -= 32;
                            r += 2;
                        }
                        if (R >= 16)
                        {
                            R -= 16;
                            r += 1;
                        }
                        int aEnlever = R;
                        R = (int)image2.matImage[i, j].Rouge;
                        R = R - aEnlever + r;

                        int V = (int)matImage[i, j].Vert;
                        int v = 0;
                        if (V >= 128)
                        {
                            V -= 128;
                            v += 8;
                        }
                        if (V >= 64)
                        {
                            V -= 64;
                            v += 4;
                        }
                        if (V >= 32)
                        {
                            V -= 32;
                            v += 2;
                        }
                        if (V >= 16)
                        {
                            V -= 16;
                            v += 1;
                        }
                        aEnlever = V;
                        V = (int)image2.matImage[i, j].Vert;
                        V = V - aEnlever + v;

                        int B = (int)matImage[i, j].Bleu;
                        int b = 0;
                        if (B >= 128)
                        {
                            B -= 128;
                            b += 8;
                        }
                        if (B >= 64)
                        {
                            B -= 64;
                            b += 4;
                        }
                        if (B >= 32)
                        {
                            B -= 32;
                            b += 2;
                        }
                        if (B >= 16)
                        {
                            B -= 16;
                            b += 1;
                        }
                        aEnlever = B;
                        B = (int)image2.matImage[i, j].Rouge;
                        B = B - aEnlever + b;*/

                        mat[i, j] = new Pixel((byte)R, (byte)V, (byte)B);
                    }
                    else
                    {
                        mat[i, j] = image2.matImage[i, j];
                    }
                }
            }

            image2.matImage = mat;
            image2.From_Image_To_File(adresseArrivee);
            return ("Succès de l'opération.");
        }

        public static void ReveleSteganographie(string adresse, string adresseImageBase, string adresseImageCachee)
        {
            MyImage image = new MyImage(adresse);
            Pixel[,] matBase = new Pixel[image.hauteur, image.largeur];
            MyImage cachee = new MyImage(image.resolutionV, image.resolutionH);
            Pixel[,] matCachee = new Pixel[image.resolutionV, image.resolutionH];

            for (int i = 0; i < cachee.matImage.GetLength(0); i++)
            {
                for (int j = 0; j < cachee.matImage.GetLength(1); j++)
                {
                    int R = (int)image.matImage[i, j].Rouge;
                    int bitsDeuxiemePartie = R % 16;
                    R -= bitsDeuxiemePartie;
                    int a = 0;
                    if (bitsDeuxiemePartie >= 8)
                    {
                        bitsDeuxiemePartie -= 8;
                        a += 128;
                    }
                    if (bitsDeuxiemePartie >= 4)
                    {
                        bitsDeuxiemePartie -= 4;
                        a += 64;
                    }
                    if (bitsDeuxiemePartie >= 2)
                    {
                        bitsDeuxiemePartie -= 2;
                        a += 32;
                    }
                    if (bitsDeuxiemePartie >= 1)
                    {
                        bitsDeuxiemePartie -= 1;
                        a += 16;
                    }
                    int r = a;


                    int V = (int)image.matImage[i, j].Vert;
                    bitsDeuxiemePartie = V % 16;
                    V -= bitsDeuxiemePartie;
                    a = 0;
                    if (bitsDeuxiemePartie >= 8)
                    {
                        bitsDeuxiemePartie -= 8;
                        a += 128;
                    }
                    if (bitsDeuxiemePartie >= 4)
                    {
                        bitsDeuxiemePartie -= 4;
                        a += 64;
                    }
                    if (bitsDeuxiemePartie >= 2)
                    {
                        bitsDeuxiemePartie -= 2;
                        a += 32;
                    }
                    if (bitsDeuxiemePartie >= 1)
                    {
                        bitsDeuxiemePartie -= 1;
                        a += 16;
                    }
                    int v = a;


                    int B = (int)image.matImage[i, j].Bleu;
                    bitsDeuxiemePartie = B % 16;
                    B -= bitsDeuxiemePartie;
                    a = 0;
                    if (bitsDeuxiemePartie >= 8)
                    {
                        bitsDeuxiemePartie -= 8;
                        a += 128;
                    }
                    if (bitsDeuxiemePartie >= 4)
                    {
                        bitsDeuxiemePartie -= 4;
                        a += 64;
                    }
                    if (bitsDeuxiemePartie >= 2)
                    {
                        bitsDeuxiemePartie -= 2;
                        a += 32;
                    }
                    if (bitsDeuxiemePartie >= 1)
                    {
                        bitsDeuxiemePartie -= 1;
                        a += 16;
                    }
                    int b = a;

                    matBase[i, j] = new Pixel((byte)R, (byte)V, (byte)B);
                    matCachee[i, j] = new Pixel((byte)r, (byte)v, (byte)b);
                }
            }
            for (int i = 0; i < matBase.GetLength(0); i++)
            {
                for (int j = 0; j < matBase.GetLength(1); j++)
                {
                    if (matBase[i, j] == null)
                    {
                        matBase[i, j] = image.matImage[i, j];
                    }
                }
            }
            image.matImage = matBase;
            image.From_Image_To_File(adresseImageBase);
            cachee.matImage = matCachee;
            image.From_Image_To_File(adresseImageCachee);
        }

        public static MyImage ReveleSteganographie2(string adresseADecoder, string adresseImageCachee)
        {
            MyImage ImADecoder = new MyImage(adresseADecoder);
            Pixel[,] matBase = new Pixel[ImADecoder.hauteur, ImADecoder.largeur];
            MyImage cachee = new MyImage(ImADecoder.resolutionH, ImADecoder.resolutionV);
            Pixel[,] matCachee = new Pixel[ImADecoder.resolutionH, ImADecoder.resolutionV];

            for (int i = 0; i < matBase.GetLength(0); i++)
            {
                for (int j = 0; j < matBase.GetLength(1); j++)
                {
                    if (i<cachee.matImage.GetLength(0) && j < cachee.matImage.GetLength(1))
                    {
                        int R = (int)ImADecoder.matImage[i, j].Rouge;
                        int bitsDeuxiemePartie = R % 16;
                        R -= bitsDeuxiemePartie;
                        int a = 0;
                        if (bitsDeuxiemePartie >= 8)
                        {
                            bitsDeuxiemePartie -= 8;
                            a += 128;
                        }
                        if (bitsDeuxiemePartie >= 4)
                        {
                            bitsDeuxiemePartie -= 4;
                            a += 64;
                        }
                        if (bitsDeuxiemePartie >= 2)
                        {
                            bitsDeuxiemePartie -= 2;
                            a += 32;
                        }
                        if (bitsDeuxiemePartie >= 1)
                        {
                            bitsDeuxiemePartie -= 1;
                            a += 16;
                        }
                        int r = a;


                        int V = (int)ImADecoder.matImage[i, j].Vert;
                        bitsDeuxiemePartie = V % 16;
                        V -= bitsDeuxiemePartie;
                        a = 0;
                        if (bitsDeuxiemePartie >= 8)
                        {
                            bitsDeuxiemePartie -= 8;
                            a += 128;
                        }
                        if (bitsDeuxiemePartie >= 4)
                        {
                            bitsDeuxiemePartie -= 4;
                            a += 64;
                        }
                        if (bitsDeuxiemePartie >= 2)
                        {
                            bitsDeuxiemePartie -= 2;
                            a += 32;
                        }
                        if (bitsDeuxiemePartie >= 1)
                        {
                            bitsDeuxiemePartie -= 1;
                            a += 16;
                        }
                        int v = a;


                        int B = (int)ImADecoder.matImage[i, j].Bleu;
                        bitsDeuxiemePartie = B % 16;
                        B -= bitsDeuxiemePartie;
                        a = 0;
                        if (bitsDeuxiemePartie >= 8)
                        {
                            bitsDeuxiemePartie -= 8;
                            a += 128;
                        }
                        if (bitsDeuxiemePartie >= 4)
                        {
                            bitsDeuxiemePartie -= 4;
                            a += 64;
                        }
                        if (bitsDeuxiemePartie >= 2)
                        {
                            bitsDeuxiemePartie -= 2;
                            a += 32;
                        }
                        if (bitsDeuxiemePartie >= 1)
                        {
                            bitsDeuxiemePartie -= 1;
                            a += 16;
                        }
                        int b = a;

                        matBase[i, j] = new Pixel((byte)R, (byte)V, (byte)B);
                        matCachee[i, j] = new Pixel((byte)r, (byte)v, (byte)b);
                    }
                    else
                    {
                        matBase[i, j] = ImADecoder.matImage[i, j];
                    }
                    
                }
            }
            for (int i = 0; i < matBase.GetLength(0); i++)
            {
                for (int j = 0; j < matBase.GetLength(1); j++)
                {
                    if (matBase[i, j] == null)
                    {
                        matBase[i, j] = ImADecoder.matImage[i, j];
                    }
                }
            }
            ImADecoder.matImage = matBase;
            cachee.matImage = matCachee;
            cachee.From_Image_To_File(adresseImageCachee);
            return ImADecoder;
        }



        public PixelAlt[,] ConversionMatAlt(Pixel[,] matImage)
        {
            PixelAlt[,] newMat = new PixelAlt[hauteur, largeur];
            for (int i = 0; i < matImage.GetLength(0); i++)
            {
                for (int j = 0; j < matImage.GetLength(1); j++)
                {
                    double Y = 0.299 * (double)matImage[i, j].Rouge + 0.587 * (double)matImage[i, j].Vert + 0.114 * (double)matImage[i, j].Bleu;
                    newMat[i, j].Y = (byte)Y;

                    double Cb = -0.1687 * (double)matImage[i, j].Rouge - 0.3313 * (double)matImage[i, j].Vert + 0.5 * (double)matImage[i, j].Bleu + 128;
                    newMat[i, j].Cb = (byte)Cb;

                    double Cr = 0.5 * (double)matImage[i, j].Rouge - 0.4187 * (double)matImage[i, j].Vert - 0.0813 * (double)matImage[i, j].Bleu + 128;
                    newMat[i, j].Cr = (byte)Cr;
                }
            }
            return newMat;
        }

        public void CompressionJPEG(string adresse)
        {
            PixelAlt[,] newMat = new PixelAlt[hauteur, largeur];
            newMat = ConversionMatAlt(matImage);
        }

        /*public void Huffmann*/
    }
}
