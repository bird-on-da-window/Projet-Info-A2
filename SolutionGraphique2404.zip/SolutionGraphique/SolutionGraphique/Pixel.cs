﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolutionGraphique
{
    internal class Pixel
    {
        private byte rouge;
        private byte vert;
        private byte bleu;


        public Pixel(byte rouge, byte vert, byte bleu)
        {
            this.rouge = rouge;
            this.vert = vert;
            this.bleu = bleu;
        }


        public byte Rouge
        {
            get { return rouge; }
            set { rouge = value; }
        }


        public byte Vert
        {
            get { return vert; }
            set { vert = value; }
        }


        public byte Bleu
        {
            get { return bleu; }
            set { bleu = value; }
        }
    }
}
